/*
 * Copyright (c) 2016-2020, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *    ======== sensor_mediumone.c ========
 */

#include <stdint.h>
#include <stddef.h>
#include <stdio.h>
#include <string.h>

/* POSIX Header files */
#include <unistd.h>

/* Driver Header files */
#include <ti/drivers/I2C.h>
#include <ti/display/Display.h>
#include <ti/drivers/UART.h>
#include <ti/drivers/apps/LED.h>
#include <ti/drivers/GPIO.h>

/* Module Header */
#include <ti/sail/bme280/bme280.h>

/* Kernel Header files */
#include <ti/sysbios/knl/Clock.h>

/* Driver configuration */
#include "ti_drivers_config.h"

#ifndef CONFIG_LEDCOUNT
#define CONFIG_LEDCOUNT        2
#endif

/**************************************/
/* Wi-Fi and Medium One Configuration */
/**************************************/

#define WIFI_SSID       "YOUR_INFO"
#define WIFI_PASSWORD   "YOUR_INFO"

#define MQTT_BROKER     "mqtt.mediumone.com"
#define MQTT_PORT       61618           /* encrypted port */
#define MQTT_USERNAME   "xxxxxxxxxxx/xxxxxxxxxxx"
#define MQTT_PASSWORD   "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx/xxxxxxxxxxxxxxxxx"
#define MQTT_PUB_TOPIC  "0/xxxxxxxxxxx/xxxxxxxxxxx/mydevice"

#define PUB_INTERVAL_MS 3000
#define ENABLE_PUBLISH  1

/***************************************/

typedef enum {
    APP_STATE_INIT = 0,
    APP_STATE_RESET_BRIDGE,
    APP_STATE_INIT_BRIDGE,
    APP_STATE_INIT_BRIDGE_CONFIRM,
    APP_STATE_CONNECT_WIFI,
    APP_STATE_CONNECT_WIFI_CONFIRM,
    APP_STATE_CONNECT_MQTT,
    APP_STATE_CONNECT_MQTT_CONFIRM,
    APP_STATE_PUBLISH_SENSOR_DATA,
    APP_STATE_PUBLISH_SENSOR_DATA_CONFIRM,
    APP_STATE_DISCONNECT_MQTT,
    APP_STATE_DISCONNECT_WIFI,
    APP_STATE_DISCONNECT_WIFI_CONFIRM,
    APP_STATE_TIMED_DELAY,
    APP_STATE_NONE
} APP_STATE_T;

APP_STATE_T app_state = APP_STATE_INIT;
APP_STATE_T next_app_state = APP_STATE_NONE;
uint32_t timed_delay_start = 0;
uint32_t timed_delay_duration = 0;

typedef struct {
    u32     iteration;      // iteration count
    u32     timestamp;      // millisecond tick count
    s32     tempc;          // temperature (C) * 100
    s32     tempf;          // temperature (F) * 100
    u32     humidity;       // humidity (%) * 1000
    u32     pressure;       // pressure (KPa) * 1000
} SENSOR_DATA_T;

SENSOR_DATA_T sensorData;
u32     iteration = 0;
s32     g_s32ActualTemp   = 0;
s32     g_s32ActualTempF  = 0;
u32     g_u32ActualPress  = 0;
u32     g_u32ActualHumity = 0;

I2C_Handle      i2c;
I2C_Params      i2cParams;

LED_Params      ledParams;
LED_Handle      ledHandle[CONFIG_LEDCOUNT];
#define RED_LED   ledHandle[CONFIG_LED_1]
#define GREEN_LED ledHandle[CONFIG_LED_0]

UART_Handle     uart;
UART_Params     uartParams;

#define SERIAL_BUF_SIZE 80

char read_buffer[SERIAL_BUF_SIZE] = {0};
char current_response[SERIAL_BUF_SIZE] = {0};
char last_response[SERIAL_BUF_SIZE] = {0};
int write_pos = 0;
bool new_response_available = 0;
uint32_t cmd_send_time;
int fail_count = 0;

static Display_Handle display;

extern s32 bme280_data_readout_template(I2C_Handle i2cHndl);
void Init_Uart(void);
void Deinit_Uart(void);
u32 Get_SysTick(void);
void DelayMs(uint32_t milliseconds);
void Run_State_Machine(void);
void Read_Sensors(SENSOR_DATA_T *sensorData);

/*
 *  ======== mainThread ========
 */
void *mainThread(void *arg0)
{
    /* Call driver init functions */
    GPIO_init();
    LED_init();
    I2C_init();
    UART_init();

    /* Open the HOST display for output */
    display = Display_open(Display_Type_UART, NULL);
    if (display == NULL) {
        while (1);
    }
    Display_print0(display, 0, 0, "\nLAUNCHXL-CC26X2R1 Connected to Medium One IoT Platform\n");

    /* Open LED0 and LED1 with default params */
    LED_Params_init(&ledParams);
    ledHandle[CONFIG_LED_0] = LED_open(CONFIG_LED_0, &ledParams);
    ledHandle[CONFIG_LED_1] = LED_open(CONFIG_LED_1, &ledParams);
    if((ledHandle[CONFIG_LED_0] == NULL) || (ledHandle[CONFIG_LED_1] == NULL))
    {
        Display_print0(display, 0, 0, "LED Open Failed!");
    }
    LED_setOn(RED_LED, 100);
    usleep(250000);
    LED_setOff(RED_LED);
    LED_setOn(GREEN_LED, 100);
    usleep(250000);
    LED_setOff(GREEN_LED);

    /* Configure the bridge reset pin and set output to high */
    GPIO_setConfig(CONFIG_GPIO_RESET_BRIDGE, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
    GPIO_write(CONFIG_GPIO_RESET_BRIDGE, 1);

    /* Initialize UART */
    Init_Uart();

    /* Open I2C */
    I2C_Params_init(&i2cParams);
    i2cParams.bitRate = I2C_400kHz;
    i2cParams.transferMode = I2C_MODE_BLOCKING;
    i2cParams.transferCallbackFxn = NULL;
    i2c = I2C_open(CONFIG_I2C_BME, &i2cParams);
    if (i2c == NULL) {
        Display_print0(display, 0, 0, "Error Initializing I2C!");
    }
    else {
        Display_print0(display, 0, 0, "I2C Initialized");
    }

    /* Initialize the BME Sensor */
    if(BME280_INIT_VALUE != bme280_data_readout_template(i2c))
    {
        Display_print0(display, 0, 0, "Error Initializing bme280!");
    }
    bme280_set_power_mode(BME280_NORMAL_MODE);

    Read_Sensors(&sensorData);
    DelayMs(200);
    iteration = 0;

#if 0
    if (BME280_INIT_VALUE == bme280_read_pressure_temperature_humidity(&g_u32ActualPress,
                &g_s32ActualTemp, &g_u32ActualHumity)) {
        g_s32ActualTempF = ((g_s32ActualTemp * 9) / 5) + 3200;
        Display_print4(display, 0, 0, "Initial reading: Pressure: %u KPa, Temp: %u.%02u DegF, Humidity: %u %% RH",
                    g_u32ActualPress/1000, g_s32ActualTempF/100, g_s32ActualTempF%100,
                    g_u32ActualHumity/1000);
    } else {
        Display_print0(display, 0, 0, "Error reading from the bme280 sensor!\n");
    }
#endif

    while (1)
    {

        Run_State_Machine();

#if 0
        if(BME280_INIT_VALUE == 
                bme280_read_pressure_temperature_humidity(&g_u32ActualPress,
                    &g_s32ActualTemp, &g_u32ActualHumity))
        {
            g_s32ActualTempF = ((g_s32ActualTemp * 9) / 5) + 3200;
            Display_print4(display, 0, 0, "Pressure: %u KPa, Temp: %u.%02u DegF, Humidity: %u %% RH\n",
                        g_u32ActualPress/1000, g_s32ActualTempF/100, g_s32ActualTempF%100,
                        g_u32ActualHumity/1000);
        }
        else
        {
            Display_print0(display, 0, 0, "Error reading from the bme280 sensor!\n");
        }
#endif

#if 0
        Read_Sensors(&sensorData);
        Display_print5(display, 0, 0, "iteration=%u, timestamp=%u, tempf=%u, humidity=%u, pressure=%u",
                      sensorData.iteration, sensorData.timestamp, sensorData.tempf, sensorData.humidity, sensorData.pressure);
        sleep(1);
#endif

    }
}

void Init_Uart(void)
{
    /* Create a UART with data processing off. */
    UART_Params_init(&uartParams);
    uartParams.writeDataMode = UART_DATA_BINARY;
    uartParams.readDataMode = UART_DATA_BINARY;
    uartParams.readReturnMode = UART_RETURN_FULL;
    uartParams.baudRate = 115200;
    uartParams.readTimeout = 0;
    uart = UART_open(CONFIG_UART_1, &uartParams);

    if (uart == NULL) {
        /* UART_open() failed */
        Display_print0(display, 0, 0, "Error Initializing UART!");
    }
}

void Deinit_Uart(void)
{
    if (uart != NULL) {
        UART_close(uart);
        uart = NULL;
    }
}

u32 Get_SysTick(void)
{
    return Clock_getTicks() / 100;  // millisecond tick count
}

void DelayMs(uint32_t milliseconds)
{
    usleep(milliseconds * 1000);
}

void Read_Sensors(SENSOR_DATA_T *sensorData)
{
    // Read sensors and populate sensor data structure
    sensorData->iteration = iteration++;
    sensorData->timestamp = Get_SysTick();
    if (BME280_INIT_VALUE == bme280_read_pressure_temperature_humidity(&g_u32ActualPress,
                &g_s32ActualTemp, &g_u32ActualHumity))
    {
        g_s32ActualTempF = ((g_s32ActualTemp * 9) / 5) + 3200;
    } else {
        Display_print0(display, 0, 0, "Error reading from the bme280 sensor!");
        g_s32ActualTemp = 0;
        g_s32ActualTempF = 0;
        g_u32ActualHumity = 0;
        g_u32ActualPress = 0;
    }
    sensorData->tempc = g_s32ActualTemp;
    sensorData->tempf = g_s32ActualTempF;
    sensorData->humidity = g_u32ActualHumity;
    sensorData->pressure = g_u32ActualPress;

    char tmp[80];
    sprintf(tmp, "hello");
}

void Process_UART(void)
{
    if (uart == NULL) {
        return;
    }
    char ch;
    int read_count = UART_read(uart, &ch, 1);
    if (read_count == 1) {
        if (ch == '\n') {  // end of response
            current_response[write_pos] = 0;
            strcpy(last_response, current_response);
            write_pos = 0;
            current_response[write_pos] = 0;
            new_response_available = 1;
        } else if (ch != 0 && ch != '\r') {  // ignore NUL & CR, keep rest
            current_response[write_pos++] = ch;
            current_response[write_pos] = 0;
        }
    }
}

void Send_Command(char *cmd)
{
    if (cmd != NULL) {
        write_pos = 0;
        current_response[write_pos] = 0;
        new_response_available = 0;
        UART_write(uart, cmd, strlen(cmd));
        cmd_send_time = Get_SysTick();
    }
}

uint32_t Response_Elapsed_Time(void)
{
    return Get_SysTick() - cmd_send_time;
}

bool isOKResponse(char *p)
{
    if (strncmp(p, "OK", 2) == 0) {
        return true;
    } else {
        return false;
    }
}

APP_STATE_T new_app_state(APP_STATE_T app_state)
{
    // Return next_app_state if it's not APP_STATE_NONE,
    // otherwise return app_state
    APP_STATE_T state = app_state;
    if (next_app_state != APP_STATE_NONE) {
        state = next_app_state;
        next_app_state = APP_STATE_NONE;
    }
    return state;
}

void set_timed_delay(uint32_t delay_ms, APP_STATE_T next_state)
{
    timed_delay_start = Get_SysTick();
    timed_delay_duration = delay_ms;
    next_app_state = next_state;
    app_state = APP_STATE_TIMED_DELAY;
}

void LED0_On(void)
{
    LED_setOn(GREEN_LED, 100);
}

void LED0_Off(void)
{
    LED_setOff(GREEN_LED);
}

void Reset_Bridge(void)
{
    GPIO_write(CONFIG_GPIO_RESET_BRIDGE, 0);
    DelayMs(1000);
    GPIO_write(CONFIG_GPIO_RESET_BRIDGE, 1);
    DelayMs(1000);
}

void Run_State_Machine(void)
{
    static char command[512];

    // Process UART responses
    Process_UART();

    // Maintain state machine
    switch (app_state) {
        case APP_STATE_INIT:
            app_state = APP_STATE_RESET_BRIDGE;
            break;
        case APP_STATE_RESET_BRIDGE:
            Display_print0(display, 0, 0, "Resetting bridge hardware...");
            Deinit_Uart();
            Reset_Bridge();
            Init_Uart();
            Display_print0(display, 0, 0, "complete");
            app_state = APP_STATE_INIT_BRIDGE;
            break;
        case APP_STATE_INIT_BRIDGE:
            Display_print0(display, 0, 0, "Initializing bridge");
            Send_Command("\n");
            DelayMs(200);
            Send_Command("AT\n");
            app_state = APP_STATE_INIT_BRIDGE_CONFIRM;
            break;
        case APP_STATE_INIT_BRIDGE_CONFIRM:
            if (new_response_available && isOKResponse(last_response)) {
                Display_print0(display, 0, 0, "Bridge initialization complete");
                app_state = APP_STATE_CONNECT_WIFI;
            } else if (Response_Elapsed_Time() > 1000) {
                Display_print0(display, 0, 0, "ERROR: Bridge not responding");
                app_state = APP_STATE_RESET_BRIDGE;
            }
            break;
        case APP_STATE_CONNECT_WIFI:
            Display_print0(display, 0, 0, "Connecting to Wi-Fi");
            sprintf(command, "AT+CWIFI={\"ssid\":\"%s\",\"password\":\"%s\"}\n",
                    WIFI_SSID, WIFI_PASSWORD);
            Send_Command(command);
            app_state = APP_STATE_CONNECT_WIFI_CONFIRM;
            break;
        case APP_STATE_CONNECT_WIFI_CONFIRM:
            if (new_response_available) {
                if (isOKResponse(last_response)) {
                    Display_print0(display, 0, 0, "Wi-Fi connect successful");
                    app_state = APP_STATE_CONNECT_MQTT;
                } else {
                    Display_print0(display, 0, 0, "ERROR: Wi-Fi connect failed, will retry");
                    set_timed_delay(5000, APP_STATE_CONNECT_WIFI);
                }
            } else if (Response_Elapsed_Time() > 20000) {
                Display_print0(display, 0, 0, "ERROR: Wi-Fi connect timed out, will retry");
                set_timed_delay(5000, APP_STATE_CONNECT_WIFI);
            }
            break;
        case APP_STATE_CONNECT_MQTT:
            Display_print0(display, 0, 0, "Connecting to MQTT broker");
            sprintf(command, "AT+CMQTT={\"host\":\"%s\",\"port\":%u,\"username\":\"%s\",\"password\":\"%s\"}\n",
                    MQTT_BROKER, MQTT_PORT, MQTT_USERNAME, MQTT_PASSWORD);
            Send_Command(command);
            app_state = APP_STATE_CONNECT_MQTT_CONFIRM;
            break;
        case APP_STATE_CONNECT_MQTT_CONFIRM:
            if (new_response_available) {
                if (isOKResponse(last_response)) {
                    Display_print0(display, 0, 0, "MQTT connect successful");
                    app_state = APP_STATE_PUBLISH_SENSOR_DATA;
                } else {
                    Display_print0(display, 0, 0, "ERROR: MQTT connect failed, will retry");
                    set_timed_delay(5000, APP_STATE_CONNECT_MQTT);
                }
            } else if (Response_Elapsed_Time() > 10000) {
                Display_print0(display, 0, 0, "ERROR: MQTT connect timed out, will retry");
                set_timed_delay(5000, APP_STATE_CONNECT_MQTT);
            }
            break;
        case APP_STATE_PUBLISH_SENSOR_DATA:
            Read_Sensors(&sensorData);
            Display_print0(display, 0, 0, "Building publish message");
            sprintf(command,
              "AT+PUBLISH={\"topic\":\"%s\",\"msg\":\"{\\\"event_data\\\":{\\\"iteration\\\":%u,\\\"timestamp\\\":%u,\\\"temp\\\":%u.%02u,\\\"humidity\\\":%u.%03u,\\\"pressure\\\":%u.%03u}}\"}\n",
                    MQTT_PUB_TOPIC,
                    (unsigned)sensorData.iteration, (unsigned)sensorData.timestamp,
                    (unsigned)sensorData.tempf / 100, (unsigned)sensorData.tempf % 100,
                    (unsigned)sensorData.humidity / 1000, (unsigned)sensorData.humidity % 1000,
                    (unsigned)sensorData.pressure / 1000, (unsigned)sensorData.pressure % 1000
                    );
            Display_print1(display, 0, 0, "%s", command);
#if ENABLE_PUBLISH == 1
            Send_Command(command);
            app_state = APP_STATE_PUBLISH_SENSOR_DATA_CONFIRM;
#else
            set_timed_delay(PUB_INTERVAL_MS, APP_STATE_PUBLISH_SENSOR_DATA);
#endif
            LED0_On();
            break;
        case APP_STATE_PUBLISH_SENSOR_DATA_CONFIRM:
            if (new_response_available) {
                LED0_Off();
                if (isOKResponse(last_response)) {
                    Display_print0(display, 0, 0, "MQTT publish successful");
                    fail_count = 0;
                    set_timed_delay(PUB_INTERVAL_MS, APP_STATE_PUBLISH_SENSOR_DATA);
                } else {
                    Display_print0(display, 0, 0, "ERROR: MQTT publish failed");
                    if (++fail_count >= 3) {
                        app_state = APP_STATE_DISCONNECT_WIFI;
                    } else {
                        set_timed_delay(PUB_INTERVAL_MS, APP_STATE_PUBLISH_SENSOR_DATA);
                    }
                }
            } else if (Response_Elapsed_Time() > 10000) {
                LED0_Off();
                Display_print0(display, 0, 0, "ERROR: MQTT publish timed out");
                if (++fail_count >= 3) {
                    app_state = APP_STATE_DISCONNECT_WIFI;
                } else {
                    // try again with no additional delay
                }
            }
            break;
        case APP_STATE_DISCONNECT_MQTT:
            /* not currently used */
            break;
        case APP_STATE_DISCONNECT_WIFI:
            Display_print0(display, 0, 0, "Disconnecting Wi-Fi");
            Send_Command("AT+DWIFI\n");
            app_state = APP_STATE_DISCONNECT_WIFI_CONFIRM;
            break;
        case APP_STATE_DISCONNECT_WIFI_CONFIRM:
            if (new_response_available) {
                if (isOKResponse(last_response)) {
                    Display_print0(display, 0, 0, "Wi-Fi disconnect successful");
                    app_state = new_app_state(APP_STATE_INIT);
                } else {
                    Display_print0(display, 0, 0, "ERROR: Wi-Fi disconnect failed");
                    app_state = new_app_state(APP_STATE_INIT);
                }
            } else if (Response_Elapsed_Time() > 10000) {
                Display_print0(display, 0, 0, "ERROR: Wi-Fi disconnect timed out");
                app_state = new_app_state(APP_STATE_INIT);
            }
            break;
        case APP_STATE_TIMED_DELAY:
            if ((Get_SysTick() - timed_delay_start) >= timed_delay_duration) {
                app_state = new_app_state(APP_STATE_INIT);
            }
        case APP_STATE_NONE:
        default:
            break;
    }
}
